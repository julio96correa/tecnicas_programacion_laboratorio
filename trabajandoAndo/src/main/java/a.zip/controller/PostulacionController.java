package controller;

public class PostulacionController {
}
