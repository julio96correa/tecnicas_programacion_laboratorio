package controller;

public class TrabajoController {
}
