import app.App;
import datastore.DataStore;

public class Main {
    public static void main(String[] args) {
        DataStore.cargarDatos();
        new App().run();
        DataStore.guardarDatos();
    }
}
