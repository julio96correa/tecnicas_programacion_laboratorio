package service;

import datastore.DataStore;
import model.Empresa;

public class EmpresaService {

    public void registrarEmpresa(String nombre, String emailCorporativo) {
        Empresa e = new Empresa(nombre, emailCorporativo, DataStore.generarId());
        DataStore.empresas.add(e);
        DataStore.guardarDatos();
        System.out.println("Empresa registrada con éxito.");
    }

    public void listarEmpresas() {
        if (DataStore.empresas.isEmpty()) {
            System.out.println("No hay empresas registradas.");
            return;
        }
        for (Empresa e : DataStore.empresas) {
            System.out.println(e);
        }
    }
}
