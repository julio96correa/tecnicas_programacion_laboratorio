package service;

import datastore.DataStore;
import model.Empresa;
import model.Trabajo;

public class TrabajoService {

    public void registrarTrabajo(Empresa empresa, String lenguaje, int tiempo, String descripcion, String idioma, double pago, boolean negociable, int disponibilidad, int experiencia) {
        Trabajo t = new Trabajo(empresa, lenguaje, tiempo, descripcion, idioma, pago, negociable, disponibilidad, experiencia);
        DataStore.trabajos.add(t);
        DataStore.guardarDatos();
        System.out.println("Trabajo registrado con éxito.");
    }

    public void listarTrabajos() {
        if (DataStore.trabajos.isEmpty()) {
            System.out.println("No hay trabajos registrados.");
            return;
        }
        for (Trabajo t : DataStore.trabajos) {
            System.out.println(t);
        }
    }
}
