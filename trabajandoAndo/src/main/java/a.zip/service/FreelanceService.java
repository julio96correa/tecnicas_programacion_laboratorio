package service;

import datastore.DataStore;
import model.Freelance;

public class FreelanceService {

    public void registrarFreelance(String nombre, String email, String[] lenguajes, double precioHora, int nivelAcademico, int experiencia, String[] idiomas) {
        Freelance f = new Freelance(DataStore.generarId(), nombre, email, lenguajes, precioHora, nivelAcademico, experiencia, idiomas);
        DataStore.freelancers.add(f);
        DataStore.guardarDatos();
        System.out.println("Freelance registrado con éxito.");
    }

    public void listarFreelancers() {
        if (DataStore.freelancers.isEmpty()) {
            System.out.println("No hay freelancers registrados.");
            return;
        }
        for (Freelance f : DataStore.freelancers) {
            System.out.println(f);
        }
    }
}
